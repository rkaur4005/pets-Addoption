
class Cat {
    constructor(api, container, template){
        this.api = api;
        this.container = document.querySelector(container);
        this.template = document.querySelector(template).innerHTML;
        this.page = 1;

        this.container.addEventListener('scroll',  () => {
            if (this.container.scrollTop + this.container.clientHeight >= this.container.scrollHeight) {
                this.page++;
                this.load();
            }
        });
    }

    click(html, data){
        //Note: We have a data object, if we wish to do something interesting, then we can use it.
        
        var div = document.createElement('div');
        div.className = "col-sm-4";
        div.innerHTML = html;
        div.addEventListener('click', function() {
            console.log(data);
            var elm = this.querySelector('.show');
            elm.style.display = window.getComputedStyle(elm).display == 'none' ? 'block' : 'none';
        })
        return div;
    }
    
    interpolate(o){
        var output = this.template.replace(/{{([^{}]*)}}/g, function (a, b) {
            var r = o[b];
            return typeof r === 'string' || typeof r === 'number' ? r : a;
        });
        return this.click(output, o);
        //return output;
    }
    append(html){
        html.forEach(elm => this.container.appendChild(elm));
    }
    async source(){
        //this.page //this will be required for every new page
        return await fetch(this.api).then(res => res.json()).then(res => res.results);
    }
    async load(){
        var html = await this.source();
        html = html.map(item => this.interpolate(item));
        this.append(html);
    }


}



