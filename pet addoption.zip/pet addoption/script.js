var cat = new Cat('https://randomuser.me/api/?results=20', '#infinite-list', '#card');
cat.load();